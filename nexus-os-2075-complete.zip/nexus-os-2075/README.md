# Nexus-OS 2075 — Think Beyond the Screen

A futuristic operating-system-inspired website built with React + Vite. It is a static site: all application logic runs in the visitor's browser, with no server, account, paid API, tracking, or database.

## Requirements

- Node.js 20 or newer (Node 20 LTS recommended)
- npm (included with Node.js)
- A GitHub account for hosting

## Run it locally

1. Download/unzip this project, then open a terminal in the `nexus-os-2075` folder.
2. Install packages: `npm install`
3. Start development: `npm run dev`
4. Open the local URL printed by Vite (usually `http://localhost:5173`).
5. Create the production build: `npm run build`. The static website is generated in `dist/`.
6. Preview that build with `npm run preview`.

## Publish to GitHub Pages (beginner steps)

1. On GitHub, create a new repository named `nexus-os-2075` (or another name). For a school project, a public repository is easiest.
2. Upload the **contents** of this project folder to the repository root, including `.github/workflows/deploy.yml`. Do not upload `node_modules/` or `dist/`.
3. Ensure the default branch is named `main`.
4. Open repository **Settings → Pages**. Under **Build and deployment → Source**, choose **GitHub Actions**.
5. Open the **Actions** tab and wait for “Build and deploy Nexus-OS to GitHub Pages” to finish successfully.
6. GitHub will show the published URL in Settings → Pages, usually `https://YOUR-USERNAME.github.io/nexus-os-2075/`.
7. To update the website, upload/commit your changes to `main`; Actions will build and publish it again.

### Vite base path

`vite.config.js` uses `base: './'`, so built assets use relative URLs and work for a GitHub Pages project repository path. If you publish to a user/organization root domain (for example `https://YOUR-USERNAME.github.io/`) or a custom domain root, change it to `base: '/'`. For a repository with another name, the current relative base normally continues to work without changes.

### Optional: Cloudflare Pages

You can use the same static project with Cloudflare Pages. Set the build command to `npm run build` and the output directory to `dist`. No server-side functions are required.

## Features

- Futuristic desktop, responsive layout, app launcher (`Ctrl+K`), local clock, taskbar, notifications, and desktop shortcuts.
- Notes and tasks saved in localStorage; task completion and deletion.
- Calculator with a small arithmetic parser (does not execute entered text as JavaScript).
- Clock, appearance settings, reduced-motion preference, and local persistence.
- Calendar event list saved locally; virtual File Manager sample files.
- Security Center can run a temporary local-storage write/read test, validate the format of Nexus saved-data keys, and report the current page protocol. Header inspection is marked “Not checked” rather than guessed.
- Nexus Arcade mini experiences, including score counters for Reaction Pulse, Number Sprint, Nexus Drift, and Nexus Explorer.
- Help and About pages.
- GitHub Actions deployment workflow.

## Important limitations

- This is a browser simulation, not a real operating system. It cannot control device settings, browse arbitrary computer files, scan the whole computer, or remove malware.
- The File Manager contains examples only. Calendar is an event list rather than a full month-grid calendar.
- Arcade currently includes lightweight mini experiences and score counters; it does **not** yet implement full Snake, block stacking, Pong, Memory Match, 2048, Minesweeper, or a full WebGL 3D game. The “Nexus Drift” and “Nexus Explorer” entries are lightweight pseudo-3D-themed prototypes, not full 3D engines.
- Window dragging is available on desktop; resizing, full keyboard window management, and advanced touch window gestures are not implemented.
- User-created data stays in browser localStorage by default. Clearing site/browser data or changing devices can remove it. Avoid storing sensitive information in this demo.

## Privacy and reset

No analytics, remote account, or external AI service is included. Notes, tasks, calendar events, and preferences are stored on the current browser profile. To reset them, use your browser's site-data controls for the page (this removes all Nexus local saves). You can also clear the relevant `nexus-*` localStorage entries from developer tools. Always review before clearing because this cannot be undone.

## Security notes

Security Center checks are intentionally limited to what the page can test. A browser page cannot reliably inspect every server response header from client-side JavaScript, and a successful local-storage test is not a general security guarantee. HTTPS status on `localhost` may show a warning during local development; that is expected.

## License

Educational project starter. Review third-party package licenses before redistributing.
