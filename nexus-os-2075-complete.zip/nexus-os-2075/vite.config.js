import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Relative asset paths work on GitHub Pages project URLs such as /repo-name/.
// For a custom root domain, change base to '/'.
export default defineConfig({ base: './', plugins: [react()] });
